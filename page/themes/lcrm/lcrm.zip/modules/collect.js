import collectjs from "collect.js";
export default collectjs;